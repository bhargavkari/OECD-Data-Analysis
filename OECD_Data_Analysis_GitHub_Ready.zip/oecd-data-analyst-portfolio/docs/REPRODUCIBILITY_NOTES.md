# Reproducibility notes

- The uploaded archive contained the OECD raw CSV and cleaned OECD, World Bank and WGI datasets, plus the corrected integrated panel and statistical outputs.
- It did not contain all original external raw downloads referenced in the data-collection notebook (including the WGI Excel workbook and World Bank metadata/source exports).
- Therefore, the integrated analysis can be run from the included processed CSVs, while fully reproducing the external source-collection step requires obtaining those missing source files and placing them in `data/raw/`.
- The final analytical panel is labelled `FIXED` in the source archive. Preserve this filename and the documented country-year validation unless you deliberately revise the methodology.
