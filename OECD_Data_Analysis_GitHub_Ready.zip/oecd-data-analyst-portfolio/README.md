# OECD Data Cleaning & External Data Integration

A data analytics portfolio project integrating OECD digital-readiness indicators with World Bank economic indicators and Worldwide Governance Indicators (WGI). The project demonstrates data cleaning, multi-source integration, exploratory analysis, statistical testing, regression modelling and diagnostic checks.

## Project highlights

- Cleaned and standardized OECD, World Bank and WGI datasets.
- Integrated country-year data into a panel covering 44 countries from 2009 to 2024.
- Performed descriptive statistics, annual trend analysis, correlation analysis and a Welch independent-samples t-test.
- Built an OLS regression model with HC3 robust standard errors.
- Reviewed model assumptions and influence using VIF, Breusch–Pagan, Shapiro–Wilk and Cook's distance diagnostics.
- Exported analytical tables and figures for review.

## Repository structure

```text
.
├── data/
│   ├── raw/
│   │   └── OECD_Going_Digital_Toolkit.csv
│   └── processed/
│       ├── OECD_Cleaned.csv
│       ├── World_Bank_Cleaned.csv
│       ├── WGI_Cleaned.csv
│       └── Final_Cleaned_OECD_Panel_2009_2024_FIXED.csv
├── notebooks/
│   ├── 01_oecd_data_cleaning.ipynb
│   ├── 02_external_data_collection_cleaning.ipynb
│   └── 03_integrated_analysis_and_statistics.ipynb
├── results/
│   ├── figures/
│   └── tables/
├── docs/
│   └── REPRODUCIBILITY_NOTES.md
├── requirements.txt
├── .gitignore
├── .gitattributes
└── README.md
```

## Tools and techniques

**Python:** Pandas, NumPy, Matplotlib, Seaborn, SciPy, Statsmodels  
**Data analytics:** data cleaning, missing-value assessment, duplicate handling, reshaping, country-name standardization, merging and validation  
**Statistics:** descriptive statistics, Pearson correlation, Welch t-test, OLS regression, HC3 robust standard errors, VIF, Breusch–Pagan test, Shapiro–Wilk test and Cook's distance.

## Analytical workflow

1. `01_oecd_data_cleaning.ipynb` — inspect and clean the OECD Going Digital Toolkit data.
2. `02_external_data_collection_cleaning.ipynb` — prepare external World Bank and WGI datasets and integrate the source data.
3. `03_integrated_analysis_and_statistics.ipynb` — run the integrated statistical analysis and generate result tables and figures.

Open the notebooks in numerical order. The integrated analysis notebook uses the supplied processed CSV files in `data/processed/`.

## Supplied data snapshot

The source project README reports these dataset dimensions:

| Dataset | Rows | Columns |
|---|---:|---:|
| OECD source extract | 3,354 | 13 |
| Cleaned OECD dataset | 1,380 | 7 |
| Cleaned World Bank dataset | 3,707 | 7 |
| Cleaned WGI dataset | 3,597 | 6 |
| Final integrated panel | 704 | 27 |

The final panel contains 704 country-year rows (44 countries across 2009–2024). OECD indicator coverage varies across countries and years.

## Selected reported findings

The supplied analysis notebook reports the following results for its 2024 sample:

- 44 countries in the 2024 cross-sectional analysis.
- Fixed broadband penetration has a positive association with Government Effectiveness (Pearson r = 0.703, p < 0.001).
- The above-median GDP-per-capita group has a higher mean fixed-broadband subscription level than the at-or-below-median group (39.98 versus 27.13 subscriptions per 100 inhabitants).
- The multiple OLS model reports R-squared = 0.631 and adjusted R-squared = 0.603 (N = 44).

These are observational associations, not evidence of causation. The results are reproduced from the supplied notebook and should be re-run if the input data or analytical choices change.

## Setup

Use Python 3.10 or later. From the repository root:

```bash
python -m venv .venv

# Windows
.venv\\Scripts\\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
jupyter notebook
```

Install dependencies with `pip install -r requirements.txt`, then open the notebooks in the `notebooks/` folder.

## Reproducibility notes

The uploaded project archive does not contain every original raw external download referenced by notebook `02_external_data_collection_cleaning.ipynb`. In particular, the World Bank source export, country metadata file and WGI Excel workbook must be obtained from their official sources and placed in `data/raw/` using the filenames referenced in that notebook.

The cleaned World Bank and WGI CSVs are included. Therefore, notebook `03_integrated_analysis_and_statistics.ipynb` can run from the supplied processed data without re-downloading those original sources. See `docs/REPRODUCIBILITY_NOTES.md` for details.

## Data sources and attribution

- OECD Going Digital Toolkit
- World Bank indicators (GDP per capita and GDP growth)
- Worldwide Governance Indicators (WGI)

Please retain source attribution and review each provider's terms before redistributing source datasets.

## Limitations

- OECD indicator coverage varies by country and year; missing values should not be interpreted as zero.
- The 2024 tests and regression are observational and cross-sectional; correlation and regression do not establish causality.
- Some raw files required to reproduce the external data-collection step are not included in this archive.
- The final cleaned panel and exported analytical tables are supplied project outputs. Review and re-run notebook cells before presenting results as independently reproduced.
